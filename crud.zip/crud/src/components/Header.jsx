import * as React from 'react';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';

const Header=()=> {
  return (
    <>
    <Box sx={{ flexGrow: 1}}>
    <AppBar position="static">
      <Toolbar variant="dense">
        <IconButton edge="start" color="inherit" aria-label="menu" sx={{  my:2 }}>
          <MenuIcon />
        </IconButton>
        <Typography variant="h5" color="inherit" component="div">
          CRUD APPLICATION
        </Typography>
      </Toolbar>
    </AppBar>
  </Box>
</>
  )
    
}

export default Header;